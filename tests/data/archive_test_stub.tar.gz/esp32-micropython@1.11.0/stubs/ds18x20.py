"""
Module: 'ds18x20' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0

class DS18X20:
    ''
    def convert_temp():
        pass

    def read_scratch():
        pass

    def read_temp():
        pass

    def scan():
        pass

    def write_scratch():
        pass

def const():
    pass

