"""
Module: 'upip' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0

class NotFoundError:
    ''
def _makedirs():
    pass

def cleanup():
    pass

cleanup_files = None
debug = None
errno = None
def expandhome():
    pass

def fatal():
    pass

file_buf = None
gc = None
def get_install_path():
    pass

def get_pkg_metadata():
    pass

gzdict_sz = 31
def help():
    pass

index_urls = None
def install():
    pass

install_path = None
def install_pkg():
    pass

def install_tar():
    pass

json = None
def main():
    pass

def op_basename():
    pass

def op_split():
    pass

os = None
def save_file():
    pass

sys = None
tarfile = None
def url_open():
    pass

usocket = None
ussl = None
uzlib = None
warn_ussl = None
