"""
Module: 'ustruct' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0
def calcsize():
    pass

def pack():
    pass

def pack_into():
    pass

def unpack():
    pass

def unpack_from():
    pass

