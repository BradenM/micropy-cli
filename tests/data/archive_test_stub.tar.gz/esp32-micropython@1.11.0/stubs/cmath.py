"""
Module: 'cmath' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0
def cos():
    pass

e = 2.718282
def exp():
    pass

def log():
    pass

def log10():
    pass

def phase():
    pass

pi = 3.141593
def polar():
    pass

def rect():
    pass

def sin():
    pass

def sqrt():
    pass

