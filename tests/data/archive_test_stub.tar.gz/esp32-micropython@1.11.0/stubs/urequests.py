"""
Module: 'urequests' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0

class Response:
    ''
    def close():
        pass

    content = None
    def json():
        pass

    text = None
def delete():
    pass

def get():
    pass

def head():
    pass

def patch():
    pass

def post():
    pass

def put():
    pass

def request():
    pass

usocket = None
