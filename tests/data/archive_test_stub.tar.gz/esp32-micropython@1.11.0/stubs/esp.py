"""
Module: 'esp' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0
LOG_DEBUG = 4
LOG_ERROR = 1
LOG_INFO = 3
LOG_NONE = 0
LOG_VERBOSE = 5
LOG_WARNING = 2
def dht_readinto():
    pass

def flash_erase():
    pass

def flash_read():
    pass

def flash_size():
    pass

def flash_user_start():
    pass

def flash_write():
    pass

def gpio_matrix_in():
    pass

def gpio_matrix_out():
    pass

def neopixel_write():
    pass

def osdebug():
    pass

