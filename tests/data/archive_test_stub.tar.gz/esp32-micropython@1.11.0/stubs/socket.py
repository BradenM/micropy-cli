"""
Module: 'socket' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0
AF_INET = 2
AF_INET6 = 10
IPPROTO_IP = 0
IPPROTO_TCP = 6
IPPROTO_UDP = 17
IP_ADD_MEMBERSHIP = 3
SOCK_DGRAM = 2
SOCK_RAW = 3
SOCK_STREAM = 1
SOL_SOCKET = 4095
SO_REUSEADDR = 4
def getaddrinfo():
    pass


class socket:
    ''
    def accept():
        pass

    def bind():
        pass

    def close():
        pass

    def connect():
        pass

    def fileno():
        pass

    def listen():
        pass

    def makefile():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def recv():
        pass

    def recvfrom():
        pass

    def send():
        pass

    def sendall():
        pass

    def sendto():
        pass

    def setblocking():
        pass

    def setsockopt():
        pass

    def settimeout():
        pass

    def write():
        pass

