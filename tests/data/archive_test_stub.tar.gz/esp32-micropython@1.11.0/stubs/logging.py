"""
Module: 'logging' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-47-g1a51fc9dd on 2019-06-18', machine='ESP32 module with ESP32')
# Stubber: 1.1.0
CRITICAL = 50
DEBUG = 10
ERROR = 40
INFO = 20

class Logger:
    ''
    def _level_str():
        pass

    def critical():
        pass

    def debug():
        pass

    def error():
        pass

    def exc():
        pass

    def exception():
        pass

    def info():
        pass

    def isEnabledFor():
        pass

    level = 0
    def log():
        pass

    def setLevel():
        pass

    def warning():
        pass

NOTSET = 0
WARNING = 30
_level = 20
_level_dict = None
_loggers = None
_stream = None
def basicConfig():
    pass

def debug():
    pass

def getLogger():
    pass

def info():
    pass

sys = None
